# simple-ini-parse
a simple lib to read and write ini file,write in c++ 11,can use by windows,linux and mac.
